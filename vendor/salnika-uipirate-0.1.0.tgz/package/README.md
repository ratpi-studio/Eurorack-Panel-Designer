# UIPIRATE

Precision-industrial UI design system — **React + Vite + vanilla-extract**.

A 4 px grid, 1 px borders, radii from 0 to 6 px, hierarchy carried by typography
and surfaces rather than by weight or shadow. One accent, reserved for states and
values. Three densities, two themes, forty components.

Implemented from a [Claude Design](https://claude.ai/design) handoff bundle; the
original HTML prototype and its conversation are kept under `design/` for
reference.

```bash
yarn install
yarn dev              # the full board on http://localhost:5173
yarn build            # the library → dist/ (ES modules, style.css, .d.ts)
yarn build:showcase   # typecheck + production build of the board → dist-showcase/
yarn typecheck
```

## Using the package

`@salnika/uipirate` is published to GitHub Packages, which asks for a token even
to install. Map the `@salnika` scope to it with a
[personal access token](https://github.com/settings/tokens) that has
`read:packages`:

```yaml
# .yarnrc.yml
npmScopes:
  salnika:
    npmRegistryServer: "https://npm.pkg.github.com"
    npmAuthToken: "${GITHUB_TOKEN}"
```

or, for npm and pnpm:

```ini
# .npmrc
@salnika:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Then `yarn add @salnika/uipirate`, import the stylesheet once at the root of the
app, and the components from the package:

```tsx
import '@salnika/uipirate/style.css';
import { ThemeProvider, Button } from '@salnika/uipirate';
```

`react` and `react-dom` (18.3 or 19) are peer dependencies. The type roles use
Geist and Geist Mono with system fallbacks; the board loads them from Google
Fonts in `index.html`, so an app has to load them too.

## Publishing

Pushing a `v*` tag runs [`publish.yml`](.github/workflows/publish.yml): it checks
the tag against `package.json`, typechecks, then `yarn npm publish` builds
`dist/` through `prepack` and publishes it with the workflow's `GITHUB_TOKEN`.

```bash
yarn version patch          # or minor / major
git commit -am "v0.1.1"
git tag v0.1.1
git push origin HEAD v0.1.1
```

## Layout

```
src/
  lib/                     the library — this is the deliverable
    theme/                 token contracts, themes, densities, accent, provider
    hooks/                 drag, focus trap, dismiss, hotkeys
    components/<Name>/     one folder per component: .tsx + .css.ts
    index.ts               the public surface
  showcase/                the board that documents every component
    sections/              one file per numbered plate (01…15)
```

Every component lives in its own folder with its styles beside it, and its doc
comment lists the states it can be in. Nothing in `lib/` imports from
`showcase/`.

## Tokens

Tokens are real CSS custom properties with stable names (`--ui-bg`, `--ui-h`, …),
declared through `createGlobalThemeContract` and assigned per attribute:

| Layer   | Selector                                       | Tokens                              |
| ------- | ---------------------------------------------- | ----------------------------------- |
| theme   | `:root`, `[data-theme="dark"\|"light"]`         | surfaces, text, signal colours      |
| density | `:root`, `[data-density="comfortable"\|"compact"\|"dense"]` | control height, padding, font size, row height |
| static  | `:root`                                        | radii, type roles                   |
| accent  | inline, per subtree                            | `ac`, `ac-ink`, `ac12`, `ac24`, `led` |

Because themes and densities are attribute overrides rather than root-only
rules, **any subtree can be flipped** — that is what makes the side-by-side
dark/light comparison in section 13 work, and what lets one panel run at a
different density from the page.

```tsx
import { ThemeProvider, ThemeScope, Button } from '@salnika/uipirate';

<ThemeProvider defaultTheme="dark" defaultDensity="compact" defaultAccent="#A8FF60">
  <Button variant="primary">Apply</Button>

  <ThemeScope theme="light">
    {/* renders light, with the accent re-resolved to its AA-safe pair */}
  </ThemeScope>
</ThemeProvider>
```

The accent is authored once as a dark-theme hex. `resolveAccent` pairs it with a
darkened variant for the light theme and derives its ink from luminance, so the
five accents from the brief (`ACCENT_OPTIONS`) all hold contrast on paper.

## Components

**Actions** Button · IconButton · SegmentedControl
**Inputs** Field · Input · NumberInput · Textarea · Select
**Selectors** Checkbox · RadioGroup · Switch
**Continuous** Slider · Knob · Fader
**Navigation** Tabs · TabPanel · SideNav · Breadcrumb · Toolbar · AppBar · StatusBar
**Containers** Panel · PanelSection · Fieldset · StatGrid · StatCell · MetricList
**Data** Table · Tree
**Overlays** Tooltip · Popover · Menu · Dialog · CommandPalette · ToastProvider
**Feedback** Badge · StatusDot · StatusRow · Progress · SegmentedProgress · Skeleton · Alert
**Signature** Meter · LedArray · SegmentDisplay · Terminal · ControlRack · Scope
**Primitives** Kbd · Divider · Overline · Readout

Plus `useDismiss`, `useFocusTrap`, `useHotkey`, `useNormalizedDrag`.

## Rules the system keeps

- **Colour never carries meaning alone.** Every switch writes its state
  (`ARMED` / `SAFE`), every toast carries a tag (`OK` / `WARN` / `ERROR`), every
  alert has a glyph and a 2 px edge.
- **Elevation only signals detachment.** Menus, popovers and tooltips share one
  surface, one 1 px border and one discreet shadow. Surfaces rise by luminance,
  never by shadow.
- **Focus is one treatment**: a 2 px accent outline at 2 px offset, or an inset
  accent ring where an outline would push neighbours around.
- **Disabled is dashed**, not just dimmed.
- **The accent is for states and values**, never for decoration.

## Interaction

Knob, fader and slider are draggable (pointer events, so touch works) and fully
keyboard-operable: arrows step, Page ↑↓ jump, Home/End go to the ends. The knob
drags relative to where the gesture started, because a knob has no track to jump
to. ⌘K / Ctrl+K opens the command palette from anywhere; Escape closes any open
surface. Tables sort and select, the tree expands, tabs and radio groups move
with the arrow keys.

The oscilloscope reads its colours from the theme's custom properties at paint
time, so the trace follows theme, accent and density without being told, and it
honours `prefers-reduced-motion` by drawing a single static frame.

## Deviations from the prototype

Three deliberate ones, all in the direction the prototype was already pointing:

1. **`[data-theme="dark"]` is emitted as well as `[data-theme="light"]`.** The
   prototype only overrode light, so its own dark/light comparison rendered two
   light panels once the page was switched to light.
2. **The fader cap travels inside its track** (`calc((100% - 12px) * …)`).
   The prototype's percentage put the cap entirely below the track at minimum.
3. **Signal-colour labels use a `signal-ink` token** that flips per theme,
   instead of a hard-coded warm black that lost contrast on the light theme's
   darker amber and red.

Everything else — spacing, borders, type roles, animation timings, the scope's
waveform maths — is transcribed from the prototype as authored.
